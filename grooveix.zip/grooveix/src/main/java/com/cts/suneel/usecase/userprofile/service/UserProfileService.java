package com.cts.suneel.usecase.userprofile.service;

import org.apache.kafka.server.authorizer.Authorizer;

import com.cts.suneel.usecase.userprofile.exceptions.UserNotFoundException;
import com.cts.suneel.usecase.userprofile.model.UserProfile;

public interface UserProfileService {
	
	UserProfile saveUser(UserProfile userProfile);
	
	UserProfile updateUser(UserProfile userProfile, long Id);
	
	String deleteUser(long id);

	UserProfile getUserById(long id);
	
    //get user by email
	UserProfile getUserByEmail(String email);

	
	

}
