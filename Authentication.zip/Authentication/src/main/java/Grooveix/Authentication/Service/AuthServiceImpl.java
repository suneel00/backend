package Grooveix.Authentication.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Grooveix.Authentication.Exception.UserAlreadyExistException;
import Grooveix.Authentication.Exception.UserNotFoundException;
import Grooveix.Authentication.Repo.AuthRepo;
import Grooveix.Authentication.model.AuthUser;

@Service
public class AuthServiceImpl implements AuthService{
	@Autowired
	private AuthRepo authRepo;
	@Override
	public boolean getAuthenticUser (String email, String password)throws UserNotFoundException {
		Optional<AuthUser> UserInfo=authRepo.findByEmailAndPassword(email, password);
		if(UserInfo.isPresent())
			return true;
		else
			throw new UserNotFoundException("User Not Found");
		
	}
	@Override
	public AuthUser registerUser(AuthUser user) throws UserAlreadyExistException {
		Optional<AuthUser> UserInfo=authRepo.findById(user.getEmail());
		if(UserInfo.isPresent()) {
			throw new UserAlreadyExistException("User Exist");
		}
		authRepo.save(user);
		return user;
	}
}
