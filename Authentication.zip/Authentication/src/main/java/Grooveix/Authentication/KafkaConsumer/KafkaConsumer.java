package Grooveix.Authentication.KafkaConsumer;

import Grooveix.Authentication.Exception.UserAlreadyExistException;
import Grooveix.Authentication.Service.AuthServiceImpl;
import Grooveix.Authentication.model.AuthUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import com.google.gson.Gson;

@Configuration
public class KafkaConsumer {
	@Autowired
	Gson gson;
	@Autowired
	AuthServiceImpl service;
	
	@KafkaListener(topics="Profile1", groupId="Group 1")
	public void register(String user)throws UserAlreadyExistException{
		AuthUser login=gson.fromJson(user, AuthUser.class);
		service.registerUser(login);
	}
}