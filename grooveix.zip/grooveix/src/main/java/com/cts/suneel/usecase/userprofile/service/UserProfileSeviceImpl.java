package com.cts.suneel.usecase.userprofile.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import com.cts.suneel.usecase.userprofile.Repository.UserProfileRepo;
import com.cts.suneel.usecase.userprofile.exceptions.UserAlreadyExistsException;
import com.cts.suneel.usecase.userprofile.exceptions.UserNotFoundException;
import com.cts.suneel.usecase.userprofile.model.UserProfile;
import com.google.gson.Gson;

@Service
public class UserProfileSeviceImpl implements UserProfileService {
    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private Gson gson;
    
    @Autowired
    private final UserProfileRepo userProfileRepo;

    public UserProfileSeviceImpl(UserProfileRepo userProfileRepo) {
        this.userProfileRepo = userProfileRepo;
    }

    @Override
    public UserProfile saveUser(UserProfile userProfile){
        Optional<UserProfile> user = userProfileRepo.findById(userProfile.getUserId());
        if (user.isPresent()) {
            throw new UserAlreadyExistsException("Existed user");
        } else {
            /*UserProfile registerData = userProfileRepo.save(userProfile);
            return registerData;*/
        	kafkaTemplate.send("music",gson.toJson(userProfile));
            return userProfileRepo.save(userProfile);
        }
    }

    @Override
    public UserProfile updateUser(UserProfile userProfile, long Id) throws UserNotFoundException {
        Optional<UserProfile> user = userProfileRepo.findById(userProfile.getUserId());
        if (user.isPresent()) {
            UserProfile updateUser = user.get();
            updateUser.setEmail(userProfile.getEmail());
            updateUser.setUsername(userProfile.getUsername());
            updateUser.setPassword(userProfile.getPassword());

            return userProfileRepo.save(updateUser);
        } else {
            throw new UserNotFoundException("user not found");
        }
    }

    @Override
    public String deleteUser(long id) {
        Optional<UserProfile> user = userProfileRepo.findById(id);
        if (user.isPresent()) {
            userProfileRepo.deleteById(id);
            return "User deleted successfully";
        } else {
            throw new UserNotFoundException("user not found");
        }
    }

    @Override
    public UserProfile getUserById(long id) {
        return userProfileRepo.findById(id).orElse(null);
    }
    @Override
    public UserProfile getUserByEmail(String email) {
        Optional<UserProfile> userDetails = userProfileRepo.getUserByEmail(email);
        if (userDetails.isPresent()){
            return userDetails.get();
        }else {
        	throw new UserNotFoundException("user Not Found with this :"+email);
        }
        //return null;
        
    }
}
