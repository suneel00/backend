package com.cts.suneel.usecase.userprofile.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.cts.suneel.usecase.userprofile.model.UserProfile;

@Repository
public interface UserProfileRepo extends JpaRepository<UserProfile,Long>{

	boolean existsByEmail(String email);
	@Query("select u from UserProfile u WHERE u.email=?1")
	Optional<UserProfile>getUserByEmail(String email);
	

}
