package com.cts.suneel.usecase.userprofile.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Optional;

@Configuration
public class Kafka {
    Optional<Integer> optionalInteger = Optional.of(1);
    Optional<Short> optionalShort = Optional.of((short)1);
    @Bean
    public NewTopic topic(){
        return new NewTopic("music", optionalInteger, optionalShort);
    }
}
