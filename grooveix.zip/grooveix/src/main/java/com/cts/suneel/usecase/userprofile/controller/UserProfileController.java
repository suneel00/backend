package com.cts.suneel.usecase.userprofile.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.suneel.usecase.userprofile.exceptions.UserAlreadyExistsException;
import com.cts.suneel.usecase.userprofile.exceptions.UserNotFoundException;
import com.cts.suneel.usecase.userprofile.model.UserProfile;
import com.cts.suneel.usecase.userprofile.service.UserProfileService;

@RestController
@RequestMapping("Grooveix/UserProfile")
public class UserProfileController {
	
	private final UserProfileService userProfileService;
	@Autowired
	public UserProfileController(UserProfileService userProfileService) {
		this.userProfileService=userProfileService;
	
	}
	//save user
	@PostMapping("/register")
	public ResponseEntity<?> saveUser(@RequestBody UserProfile userProfile) throws UserAlreadyExistsException{
		try {
			return ResponseEntity.ok(userProfileService.saveUser(userProfile));
		}catch(UserAlreadyExistsException e) {
			throw new UserAlreadyExistsException(e.getMessage());
		}
	}
	//update user
	@PutMapping("/updateUser/{id}")
	public ResponseEntity<?> updateUser(@RequestBody UserProfile user,@PathVariable("id")long id) throws UserNotFoundException {
		try {
			return ResponseEntity.ok(userProfileService.updateUser(user, id));
		}catch (UserNotFoundException e){
			throw new UserNotFoundException(e.getMessage());
		}
		
	}
	//delete user
	@DeleteMapping("/userDelete/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable("id")long id)throws UserNotFoundException{
		try {
			return ResponseEntity.ok(userProfileService.deleteUser(id));
			
		}catch(UserNotFoundException e) {
			throw new UserNotFoundException(e.getMessage());
		}
	}
	//find by id
	 @GetMapping("/getUserById/{id}")
	    public ResponseEntity<?> getUserById(@PathVariable("id") long id) {
	        UserProfile userProfile = userProfileService.getUserById(id);
	        if (userProfile != null) {
	            return ResponseEntity.ok(userProfile);
	        } else {
	            // Handle case when user is not found
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
	        }
	    }

		/*
		 * //find user by email
		 * 
		 * @GetMapping("/getUserByEmail/{email}") public ResponseEntity<?>
		 * getUserByEmail(@PathVariable("email") String email){ return new
		 * ResponseEntity<>(userProfileService.getUserByEmail(email), HttpStatus.OK);
		 * 
		 * }
		 */
	 @GetMapping("/getUserByEmail/{email}")
		public ResponseEntity<?> getUserByEmail(@PathVariable("email")String email)throws UserNotFoundException{
			try {
				return ResponseEntity.ok(userProfileService.getUserByEmail(email));
				
			}catch(UserNotFoundException e) {
				throw new UserNotFoundException(e.getMessage());
			}
		}

}
