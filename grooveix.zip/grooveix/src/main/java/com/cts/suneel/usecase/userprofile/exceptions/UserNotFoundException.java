package com.cts.suneel.usecase.userprofile.exceptions;

public class UserNotFoundException extends RuntimeException {
	private String message;
	public UserNotFoundException(String message) {
		super(message);
		this.message=message;
	}

}
